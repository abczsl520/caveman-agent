"""SQLite memory store helpers — extracted to keep sqlite_store.py under 400 lines.

Schema versioning (PRD §8.9.6 + §8.12):
  Current: SCHEMA_VERSION = 1 (v0.4.0 baseline)
  Migration: schema_version table + numbered, transactional migration functions.
  Dry-run: inspect pending migrations without mutating the database.
"""
from __future__ import annotations

import json
import logging
import sqlite3
from datetime import datetime
from typing import Callable

from .types import MemoryType, MemoryEntry

__all__ = [
    "SCHEMA_VERSION",
    "row_to_entry",
    "get_schema_version",
    "pending_migrations",
    "migrate_schema",
]


logger = logging.getLogger(__name__)

# PRD §8.9.6: Schema version. Increment when adding/changing columns.
SCHEMA_VERSION = 1


def _ensure_schema_version_table(conn: sqlite3.Connection) -> None:
    conn.execute(
        "CREATE TABLE IF NOT EXISTS schema_version ("
        "component TEXT PRIMARY KEY, "
        "version INTEGER NOT NULL, "
        "applied_at TEXT NOT NULL"
        ")"
    )


def get_schema_version(conn: sqlite3.Connection, component: str = "memory") -> int:
    """Return tracked schema version for a component, creating the table if needed."""
    _ensure_schema_version_table(conn)
    row = conn.execute(
        "SELECT version FROM schema_version WHERE component = ?", (component,)
    ).fetchone()
    return int(row[0]) if row else 0


def _set_schema_version(conn: sqlite3.Connection, version: int, component: str = "memory") -> None:
    _ensure_schema_version_table(conn)
    conn.execute(
        "INSERT INTO schema_version(component, version, applied_at) "
        "VALUES (?, ?, ?) "
        "ON CONFLICT(component) DO UPDATE SET "
        "version = excluded.version, applied_at = excluded.applied_at",
        (component, version, datetime.now().isoformat()),
    )


def _migration_001_baseline_columns(conn: sqlite3.Connection) -> None:
    """Ensure v1 baseline additive columns exist on legacy memory DBs."""
    existing = {row[1] for row in conn.execute("PRAGMA table_info(memories)").fetchall()}
    migrations = [
        ("trust_score", "ALTER TABLE memories ADD COLUMN trust_score REAL DEFAULT 0.5"),
        ("retrieval_count", "ALTER TABLE memories ADD COLUMN retrieval_count INTEGER DEFAULT 0"),
        ("helpful_count", "ALTER TABLE memories ADD COLUMN helpful_count INTEGER DEFAULT 0"),
        ("entities_json", "ALTER TABLE memories ADD COLUMN entities_json TEXT DEFAULT '[]'"),
    ]
    for col, sql in migrations:
        if col not in existing:
            conn.execute(sql)
            logger.info("Schema migration v1: added column '%s'", col)


_MIGRATIONS: list[tuple[int, str, Callable[[sqlite3.Connection], None]]] = [
    (1, "baseline additive memory columns", _migration_001_baseline_columns),
]


def pending_migrations(conn: sqlite3.Connection) -> list[tuple[int, str]]:
    """Return pending memory schema migrations without mutating memory data."""
    current = get_schema_version(conn)
    return [(version, name) for version, name, _ in _MIGRATIONS if version > current]


def row_to_entry(row, fts_rank: float | None = None, trust: float | None = None,
                 retrieval_count: int | None = None) -> MemoryEntry:
    """Convert a DB row to MemoryEntry. Unified for all query types.

    Be deliberately tolerant: one corrupt legacy row must not make recall fail
    for the whole agent loop. Bad metadata/type/date values are logged with the
    memory id and downgraded to safe defaults.
    """
    memory_id = row[0]
    try:
        meta = json.loads(row[4]) if row[4] else {}
        if not isinstance(meta, dict):
            logger.warning("Memory row %s has non-object metadata_json; using empty metadata", memory_id)
            meta = {}
    except (json.JSONDecodeError, TypeError) as exc:
        logger.warning("Memory row %s has invalid metadata_json: %s", memory_id, exc)
        meta = {}

    if fts_rank is not None:
        meta["_fts_rank"] = fts_rank
    if trust is not None:
        # trust_score column is the source of truth; metadata_json may contain
        # the initial value from creation time and must not shadow live updates.
        meta["trust_score"] = trust
    elif len(row) > 5:
        meta["trust_score"] = row[5]
    if retrieval_count is not None:
        meta["retrieval_count"] = retrieval_count

    try:
        memory_type = MemoryType(row[2])
    except ValueError:
        logger.warning("Memory row %s has invalid type %r; falling back to semantic", memory_id, row[2])
        memory_type = MemoryType.SEMANTIC

    try:
        created_at = datetime.fromisoformat(row[3])
    except (ValueError, TypeError) as exc:
        logger.warning("Memory row %s has invalid created_at %r: %s", memory_id, row[3], exc)
        created_at = datetime.now()

    return MemoryEntry(
        id=memory_id, content=row[1],
        memory_type=memory_type,
        created_at=created_at,
        metadata=meta,
    )


def migrate_schema(conn: sqlite3.Connection, dry_run: bool = False) -> list[tuple[int, str]]:
    """Apply numbered memory schema migrations transactionally.

    PRD §8.12: migrations are tracked in a `schema_version` table and can be
    inspected with dry-run before mutating the database. Each version is applied
    inside one transaction; failure rolls back that version.
    """
    pending = pending_migrations(conn)
    if dry_run:
        return pending

    for version, name, fn in _MIGRATIONS:
        if version <= get_schema_version(conn):
            continue
        try:
            conn.execute("BEGIN")
            fn(conn)
            _set_schema_version(conn, version)
            conn.commit()
            logger.info("Schema migration v%d complete: %s", version, name)
        except Exception:
            conn.rollback()
            logger.exception("Schema migration v%d failed; rolled back", version)
            raise
    return pending
