"""Regression tests for memory subsystem self-audit fixes."""
from __future__ import annotations

def test_mcp_memory_manager_uses_sqlite_backend():
    """MCP tools must share the production memory graph, not legacy JSON files."""
    manager = mcp_server._memory_manager()

    try:
        assert isinstance(manager.backend, SQLiteMemoryStore)
    finally:
        if hasattr(manager.backend, "close"):
            manager.backend.close()

from datetime import datetime
from unittest.mock import AsyncMock

import pytest

from caveman.memory.manager import MemoryManager
from caveman.memory.sqlite_store import SQLiteMemoryStore
from caveman.mcp import server as mcp_server
from caveman.memory.types import MemoryEntry, MemoryType


def test_memory_manager_get_by_id_sqlite(tmp_path):
    async def _run():
        mm = MemoryManager.with_sqlite(base_dir=tmp_path, db_path=tmp_path / "mem.db")
        mid = await mm.store(
            "A durable memory with a unique lookup token alpha123",
            MemoryType.SEMANTIC,
            metadata={"trust_score": 0.7},
            trusted=True,
        )
        found = await mm.get_by_id(mid)
        missing = await mm.get_by_id("missing")
        assert found is not None
        assert found.id == mid
        assert found.content.startswith("A durable memory")
        assert found.metadata["trust_score"] == 0.7
        assert missing is None

    asyncio.run(_run())


@pytest.mark.asyncio
async def test_nudge_does_not_report_rejected_store():
    class RejectingMemory:
        async def recall(self, *args, **kwargs):
            return []

        def recent(self, *args, **kwargs):
            return []

        def search_sync(self, *args, **kwargs):
            return []

        async def store(self, *args, **kwargs):
            return ""

    nudge = MemoryNudge(RejectingMemory(), llm_fn=None)
    nudge.drift_detector.check = AsyncMock(return_value=None)
    created = await nudge.run([
        {"role": "assistant", "content": "decided use sqlite memory backend for reliable recall"},
    ], task="memory audit")
    assert created == []


def test_phase_finalize_marks_recalled_memory_based_on_actual_content(tmp_path):
    async def _run():
        from caveman.agent.phases import phase_finalize
        from caveman.events import EventBus

        mm = MemoryManager.with_sqlite(base_dir=tmp_path, db_path=tmp_path / "mem.db")
        used = await mm.store(
            "Use pytest fail-fast when debugging regressions",
            MemoryType.PROCEDURAL,
            metadata={"trust_score": 0.5},
            trusted=True,
        )
        unused = await mm.store(
            "Deploy frontend with nginx blue green release",
            MemoryType.PROCEDURAL,
            metadata={"trust_score": 0.5},
            trusted=True,
        )

        class Skills:
            def record_outcome(self, *args, **kwargs):
                pass

            async def auto_create(self, *args, **kwargs):
                pass

        class Trajectory:
            def to_sharegpt(self):
                return []

            async def save(self):
                pass

        await phase_finalize(
            task="debug regression",
            final="Fixed by running pytest fail-fast and patching the failing assertion.",
            matched_skills=[],
            memory_manager=mm,
            skill_manager=Skills(),
            trajectory_recorder=Trajectory(),
            bus=EventBus(),
            recalled_ids=[used, unused],
        )
        used_entry = await mm.get_by_id(used)
        unused_entry = await mm.get_by_id(unused)
        assert used_entry.metadata["trust_score"] > 0.5
        assert unused_entry.metadata["trust_score"] < 0.5

    asyncio.run(_run())
